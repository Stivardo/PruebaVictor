# AerolineaVisual
WindowsForm C#
Programa visual para la compra y reservacion de vuelos ademas de algoritmos 
como PRIM, Kruskal, dikstra y Dijkstra, que se utiliza en grafos 
PRIM
Kruskal(árbol recubridor mínimo  en un grafo conexo y ponderado)
dikstra( árbol recubridor mínimo en un grafo conexo, no dirigido y cuyas aristas están etiquetadas)
Dijkstra( determinación del camino más corto, dado un vértice origen, hacia el resto de los vértices en un grafo que tiene pesos en cada arista)
